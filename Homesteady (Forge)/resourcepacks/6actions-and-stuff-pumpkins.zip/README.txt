- Actions & Stuff Pumpkins + No Blur , by wyv :3

- This is a custom pumpkin texture pack for Minecraft Java Edition.
- If you like it, check for the latest updates here:  
- https://www.planetminecraft.com/texture-pack/action-s-amp-stuff-pumpkin-java-no-blur/