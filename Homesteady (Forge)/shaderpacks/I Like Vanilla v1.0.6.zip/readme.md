## Thank you for using my shader!

If you find an issue with the shader, please report it [here](https://github.com/What42Pizza/I-Like-Vanilla/issues). I'm not sure how this will go, but I'm sure I'll adapt to whatever comes up. If you need to contact me, my Discord name is What42Pizza.

<br>

- **[Repository](https://github.com/What42Pizza/I-Like-Vanilla)**
- **[Official Download](https://modrinth.com/shader/what42s-shader-base)** (Modrinth, recommended)
- **[Official Download](https://legacy.curseforge.com/minecraft/shaders/what42s-shader-base)** (CurseForge)
- **[License](LICENSE)**
